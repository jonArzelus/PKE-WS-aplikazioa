	<footer class='main' id='f1'>

		<!-- <?php
			echo '<div class="botoia-left"> Erabiltzailea: <strong>' . $_SESSION['eposta'] . '</strong> - ' . $_SESSION['erabiltzaileMota'] . '</div>';
		?> -->

		<b> © <a style="text-decoration: none" target="_blank" href="https://www.linkedin.com/in/jon-arzelus-rodriguez-63306b128">Jon Arzelus</a> eta <a style="text-decoration: none" target="_blank" href='inaki.html'>Iñaki Berriotxoa</a></b>
		<a target="_blank" href='https://github.com/berrio86/wsGit16'><img src="irudiak/github-icon.png"></a>
		<a target="_blank" href='http://en.wikipedia.org/wiki/Quiz'><img src="irudiak/wikipedia-icon.png"></a>
	</footer>
</div>
</body>
</html>