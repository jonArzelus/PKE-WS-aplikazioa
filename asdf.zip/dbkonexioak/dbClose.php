<?php
$db->close();
?>
