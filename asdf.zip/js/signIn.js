
  $('.login').slideUp(500);
  $('.error-page').slideDown(1000);


$('.try-again').click(function(){
  $('.error-page').hide(0);
  $('.login').slideDown(1000);
});